
public class Paczka {

	
	public String Priorytet;
	public String Fragile;
	public String Waga;
	public double RozmX;
	public double RozmY;
	public double RozmZ;
	
	public Paczka( String P, String F, String W,
			double X, double Y, double Z){
		
		Priorytet = P;
		Fragile = F;
		Waga = W;
		RozmX = X;
		RozmY = Y;
		RozmZ = Z;
	
	}

	
	
	
	
}
